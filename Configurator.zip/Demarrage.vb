﻿Public Class Demarrage

    Private Sub Demarrage_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        PictureBox1.ImageLocation = "http://image.noelshack.com/fichiers/2014/41/1413108367-294.gif"
    End Sub
End Class